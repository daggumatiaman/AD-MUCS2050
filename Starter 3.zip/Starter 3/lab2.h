#include <stdio.h>
#include <stdlib.h>

int * makeArray(int size);

void fillFives(int *array, int size);

void freeArray(int **array);
