#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include "bst.h"

// Local functions

// These are stubs.  That is, you need to implement these functions.

BST *NewBST()
{
    BST *database = malloc(sizeof(BST));

    if (database == NULL)
        return NULL;

    database->left = NULL;
    database->right = NULL;
    database->parent = NULL;
    database->object = NULL;
    database->key = 0;
    return database;
}

void TreeInsert(BST *pBST, void *satellite, long long key)
{
    /*
    pBST->root->object = satellite;
    pBST->root->key = key;
    */
    BST *z = malloc(sizeof(BST));
    if (z == NULL)
        return;
    z->object = satellite;
    z->key = key;
    BST *y = NULL;
    BST *x = pBST;

    while (x != NULL)
    {
        y = x;
        if (z->key < x->key)
        {
            x = x->left;
        }
        else
        {
            x = x->right;
        }
    }

    pBST->parent = y;
    if (y == NULL)
    {
        pBST = z;
    }
    else if (z->key < y->key)
    {
        y->left = z;
    }
    else
    {
        y->right = z;
    }
}

void InOrder(BST *p, NODEVISITFUNC func)
{
    if (p != NULL)
    {
        InOrder(p->left, func);
        func(p);
        InOrder(p->right, func);
    }
}

void PreOrder(BST *pBST, NODEVISITFUNC func)
{
    if (pBST != NULL)
    {
        func(pBST);
        PreOrder(pBST->left, func);
        PreOrder(pBST->right, func);
    }
}

void PostOrder(BST *pBST, NODEVISITFUNC func)
{
    if (pBST != NULL)
    {
        PostOrder(pBST->left, func);
        PostOrder(pBST->right, func);
        func(pBST);
    }
}

void *Search(BST *pBST, long long key)
{
    if (pBST == NULL || key == pBST->key)
    {
        return pBST;
    }
    if (key < pBST->key)
    {
        return Search(pBST->left, key);
    }
    else
    {
        return Search(pBST->right, key);
    }
    return NULL;
}

void *TreeMIN(BST *pBST)
{
    if (pBST == NULL)
        return NULL;
    while (pBST->left != NULL)
    {
        pBST = pBST->left;
    }
    return pBST;
}

void *TreeSuccessor(BST *pBST)
{
    if (pBST == NULL)
        return NULL;
    if (pBST->right != NULL)
    {
        return TreeMIN(pBST->right);
    }

    BST *y = pBST->parent;
    while (y != NULL && pBST == y->right)
    {
        pBST = y;
        y = y->parent;
    }

    return y;
}

void TreeDelete(BST *pBST, long long key)
{
    BST *z = Search(pBST, key);
    if (z == NULL)
        return;
    BST *y = NULL;
    BST *x = NULL;

    if (z->left == NULL || z->right == NULL)
    {
        y = z;
    }
    else
    {
        y = TreeSuccessor(z);
    }

    if (y->left != NULL)
    {
        pBST = y->left;
    }
    else
    {
        pBST = y->right;
    }

    if (x != NULL)
    {
        x->parent = y->parent;
    }

    if (y->parent == NULL)
    {
        pBST = x;
    }
    else if (y == x->parent->left)
    {
        y->parent->left = x;
    }
    else
    {
        y->parent->right = x;
    }

    if (y != z)
    {
        z->key = y->key;
        z->object = y->object;
    }
}
